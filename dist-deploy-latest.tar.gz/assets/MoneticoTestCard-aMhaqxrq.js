import"./vendor-react-KRyrE2BR.js";import"./vendor-Cmmw5xZ1.js";function r(){return null}export{r as MoneticoTestCard};
